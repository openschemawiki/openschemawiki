// MedicalRecord schema
export type MedicalRecord = {
  id: string;                    // Unique identifier for the medical record
  patientId: string;              // Unique identifier for the patient
  doctorId: string;               // Unique identifier for the doctor
  visitDate: Date;                // Date of the medical visit
  diagnosis: string;              // Diagnosis made during the visit
  treatments: Treatment[];        // List of treatments prescribed or administered
  prescriptions: Prescription[];  // List of prescriptions given during the visit
  notes?: string;                 // Optional field for additional notes or observations
  followUpDate?: Date;            // Optional field for scheduling follow-up appointments
  attachments?: string[];         // Optional field for storing file paths or URLs to related documents (e.g., lab results, imaging)
};

// Treatment schema
type Treatment = {
  type: string;                   // Type of treatment (e.g., surgery, physical therapy)
  description: string;            // Description of the treatment provided
  date: Date;                     // Date of treatment
};

// Prescription schema
type Prescription = {
  medicationName: string;         // Name of the medication prescribed
  dosage: string;                 // Dosage information
  frequency: string;              // Frequency of administration (e.g., once daily)
  duration: string;               // Duration of the prescription (e.g., 10 days)
  startDate: Date;                // Start date of the prescription
};

