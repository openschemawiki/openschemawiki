# MedicalRecord Schema

This project defines a TypeScript schema for a `MedicalRecord`, designed to capture essential information from a patient's medical visit.

## Overview

The `MedicalRecord` schema is used to store key details such as the patient, doctor, diagnosis, treatments, prescriptions, and optional follow-up information. It provides a clear structure for handling medical records efficiently.

## Schema Structure

### MedicalRecord
- `id`: Unique identifier for the medical record.
- `patientId`: Unique identifier for the patient.
- `doctorId`: Unique identifier for the attending doctor.
- `visitDate`: Date of the patient's medical visit.
- `diagnosis`: Diagnosis provided during the visit.
- `treatments`: List of treatments administered during the visit.
- `prescriptions`: List of medications prescribed during the visit.
- `notes`: (Optional) Additional observations or comments.
- `followUpDate`: (Optional) Date for any follow-up appointments.
- `attachments`: (Optional) URLs or file paths for related documents (e.g., lab results).

### Treatment
- `type`: The type of treatment (e.g., surgery, therapy).
- `description`: A description of the treatment provided.
- `date`: Date when the treatment was administered.

### Prescription
- `medicationName`: Name of the prescribed medication.
- `dosage`: Dosage details.
- `frequency`: How often the medication should be taken.
- `duration`: How long the prescription is valid.
- `startDate`: Start date of the prescription.

## Usage

To use this schema in your project, import or define the `MedicalRecord`, `Treatment`, and `Prescription` types in your TypeScript code. This provides a standard structure for managing medical records within your application.

```typescript
import { MedicalRecord, Treatment, Prescription } from './MedicalRecordSchema';
```

## License

This schema is open-source and available under the MIT License.