export interface Thing {
	/**
	 * An additional type for the item, typically used for adding more specific
	 * types from external vocabularies in microdata syntax. This is a
	 * relationship between something and a class that the thing is in. Typically
	 * the value is a URI-identified RDF class, and in this case corresponds to
	 * the use of rdf:type in RDF. Text values can be used sparingly, for cases
	 * where useful information can be added without their being an appropriate
	 * schema to reference. In the case of text values, the class label should
	 * follow the schema.org style guide.
	 */
	additionalType?: string;
	/**
	 * An alias for the item.
	 */
	alternateName?: string;
	/**
	 * A short description of the item.
	 */
	description?: string;
	/**
	 * A sub property of description. A short description of the item used to
	 * disambiguate from other, similar items. Information from other properties
	 * (in particular, name) may be necessary for the description to be useful for
	 * disambiguation.
	 */
	disambiguatingDescription?: string;
	/**
	 * The identifier property represents any kind of identifier for any kind of
	 * Thing, such as ISBNs, GTIN codes, UUIDs etc. Schema.org provides dedicated
	 * properties for representing many of these, either as textual strings or as
	 * URL (URI) links. See background notes for more details.
	 */
	identifier?: string;
}